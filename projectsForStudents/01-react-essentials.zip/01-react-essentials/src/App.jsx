/**
 * 1. Crear un nuevo componente Header
 *
 * 2. Dinamizar contenido const reactDescriptions = ["Fundamental", "Crucial", "Core"];
 *    function genRandomInt(max) {return Math.floor(Math.random() * (max + 1));}
 *
 * 3. Importar imagenes para preparar la subida a pro
 *
 * 4. Crear componente nuevo CoreConceps (li -> img, h2, p)
 *
 * 5. Obtener datos de CoreConcepts desde data.js
 *
 **/

function App() {
  return (
    <div>
      <header>
        <img src="src/assets/react-core-concepts.png" alt="Stylized atom" />
        <h1>React Essentials</h1>
        <p>
          Fundamental React concepts you will need for almost any app you are
          going to build!
        </p>
      </header>
      <main>
        <h2>Time to get started!</h2>
      </main>
    </div>
  );
}

export default App;
